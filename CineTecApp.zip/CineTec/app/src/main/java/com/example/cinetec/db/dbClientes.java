package com.example.cinetec.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.cinetec.entidades.Cliente;

import java.util.ArrayList;

public class dbClientes extends DbHelper {

    Context context;

    public dbClientes(@Nullable Context context) {
        super(context);
        this.context = context;
    }



    public void insertarCliente(int CedulaCliente, String NombreCliente1,String NombreCliente2,String ApellidoCliente1,String ApellidoCliente2,String FechaNacimiento, int NumeroTelefono,int estado) {


        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("cedulacliente",CedulaCliente);
            values.put("nombrecliente1",NombreCliente1);
            values.put("nombrecliente2",NombreCliente2);
            values.put("apellidocliente1",ApellidoCliente1);
            values.put("apellidocliente2",ApellidoCliente2);
            values.put("fechanacimiento",FechaNacimiento);
            values.put("numerotelefono",NumeroTelefono);
            values.put("estado_sincro", estado);



            db.insert(TABLE_CLIENTES, null, values);
        } catch (Exception ex) {
            ex.toString();
        }
    }

    public ArrayList<Cliente> mostrarClientes() {

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<Cliente> listaclientes = new ArrayList<>();
        Cliente cliente;
        Cursor cursorClientes;

        cursorClientes = db.rawQuery("SELECT * FROM " + TABLE_CLIENTES, null);

        if (cursorClientes.moveToFirst()) {
            do {
                cliente = new Cliente();
                cliente.setCedulacliente(cursorClientes.getInt(0));
                cliente.setNombrecliente1(cursorClientes.getString(1));
                cliente.setNombrecliente2(cursorClientes.getString(2));
                cliente.setApellidocliente1(cursorClientes.getString(3));
                cliente.setApellidocliente2(cursorClientes.getString(4));
                cliente.setFechanacimiento(cursorClientes.getString(5));
                cliente.setNumerotelefono(cursorClientes.getInt(6));
                listaclientes.add(cliente);
            } while (cursorClientes.moveToNext());
        }

        cursorClientes.close();
        return listaclientes;
    }
}
