package com.example.cinetec;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cinetec.db.DbHelper;
import com.example.cinetec.db.dbFunciones;
import com.example.cinetec.entidades.funciones;
import com.example.cinetec.services.FuncionService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class proyec_peli extends AppCompatActivity {

    private TextView tvtittle;
    private String PeliId;
    ArrayList<String> listahoras = new ArrayList<>();
    private ListView listap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proyec_peli);


        tvtittle= (TextView)findViewById(R.id.textViewproyc);
        String dato= getIntent().getStringExtra("nom");
        tvtittle.setText(dato);

        PeliId= getIntent().getStringExtra("PeliID");
        listap = (ListView) findViewById(R.id.list_proy);
        listahoras=getlisthoras();

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, R.layout.list_item, listahoras);
        listap.setAdapter(adapter1);

        actualizaBDSQlite();


    }

    private boolean verificaConexionInternet() {

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }

    private void actualizaBDSQlite(){
        if (verificaConexionInternet()){
            resetearTablafun();
            getfunc();
        }else{
            Toast.makeText(this,"Sin acceso a internet. Uso de datos locales",Toast.LENGTH_LONG).show();
        }
    }

    public void resetearTablafun(){
        DbHelper dbHelper= new DbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DROP TABLE t_Funcion");

        db.execSQL("CREATE TABLE t_Funcion (SalaID TEXT NOT NULL,Hora TEXT NOT NULL,PeliID TEXT NOT NULL,FuncionID TEXT PRIMARY KEY)");
    }


    public void insertandofunc(List<funciones> lista){
        dbFunciones dbpeli= new dbFunciones(this);

        for(int i=0; i<lista.size();i++) {

            funciones Pl = lista.get(i);
            String peliid = Pl.getPeliid();
            String salaid = Pl.getSalaid();
            String hora = Pl.getHora();
            String funcionid = Pl.getFuncionid();


            dbpeli.insertarFunciones(salaid,peliid,hora,funcionid);
        }
    }

    private void getfunc() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.118:8081/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        FuncionService peliService = retrofit.create(FuncionService.class);
        Call<List<funciones>> call = peliService.getfuncion();

        List<funciones> listasur;
        call.enqueue(new Callback<List<funciones>>() {
            @Override
            public void onResponse(Call<List<funciones>> call, Response<List<funciones>> response) {
                try {
                    if (response.isSuccessful()) {
                        List<funciones> FCList = response.body();
                        insertandofunc(FCList);
                        //Toast.makeText(inicial.this, "Exitoso", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(proyec_peli.this, "Unsuccessful Clients GET", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Toast.makeText(proyec_peli.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<funciones>> call, Throwable t) {
                Toast.makeText(proyec_peli.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public ArrayList<String> getlisthoras(){
        dbFunciones dbfunc= new dbFunciones(this);
        ArrayList<funciones> listafun = new ArrayList<>();
        listafun=dbfunc.mostrarFunciones(PeliId);
        ArrayList<String> listahoras = new ArrayList<>();

        int i=0;
        while (i < listafun.size()){
            String aux= "Sala: " + listafun.get(i).getSalaid()+ "\n" + "Fecha: " + listafun.get(i).getHora();
            listahoras.add(aux);
            i++;
        }
        return listahoras;
    }
}
