package com.example.cinetec.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.cinetec.entidades.funciones;
import com.example.cinetec.peli_acti;

import java.util.ArrayList;

public class dbFunciones extends DbHelper {


    Context context;

    public dbFunciones(@Nullable Context context) {
        super(context);
        this.context = context;
    }


    public void insertarFunciones(String SalaID,String PeliID,String Hora, String FuncionID) {

        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("SalaID", SalaID);
            values.put("PeliID", PeliID);
            values.put("Hora", Hora);
            values.put("FuncionID", FuncionID);

            db.insert(TABLE_FUNCION, null, values);
        } catch (Exception ex) {
            ex.toString();
        }
    }

    public ArrayList<funciones> mostrarFunciones(String PeliID) {

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<funciones> listafunciones = new ArrayList<>();
        funciones funcion;
        Cursor cursorFuncion;
        cursorFuncion = db.rawQuery("select * from " + TABLE_FUNCION+" where PeliID =?", new String[]{PeliID});

        if (cursorFuncion.moveToFirst()) {
            do {
                funcion = new funciones();
                funcion.setSalaid(cursorFuncion.getString(0));
                funcion.setPeliid(cursorFuncion.getString(2));
                funcion.setHora(cursorFuncion.getString(1));
                funcion.setFuncionid(cursorFuncion.getString(3));
                listafunciones.add(funcion);
            } while (cursorFuncion.moveToNext());
        }

        cursorFuncion.close();

        return listafunciones;
    }


}
