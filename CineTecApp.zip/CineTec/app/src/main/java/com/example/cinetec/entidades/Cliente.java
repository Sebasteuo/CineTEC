package com.example.cinetec.entidades;

public class Cliente {

    private int cedulacliente;
    private String nombrecliente1;
    private String nombrecliente2 ;
    private String apellidocliente1;
    private String apellidocliente2;
    private String fechanacimiento;
    private int numerotelefono;
    private String usuario;
    private String contrasenna;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenna() {
        return contrasenna;
    }

    public void setContrasenna(String contrasenna) {
        this.contrasenna = contrasenna;
    }




    public int getCedulacliente() {
        return cedulacliente;
    }

    public void setCedulacliente(int cedulacliente) {
        this.cedulacliente = cedulacliente;
    }

    public String getNombrecliente1() {
        return nombrecliente1;
    }

    public void setNombrecliente1(String nombrecliente1) {
        this.nombrecliente1 = nombrecliente1;
    }

    public String getNombrecliente2() {
        return nombrecliente2;
    }

    public void setNombrecliente2(String nombrecliente2) {
        this.nombrecliente2 = nombrecliente2;
    }

    public String getApellidocliente1() {
        return apellidocliente1;
    }

    public void setApellidocliente1(String apellidocliente1) {
        this.apellidocliente1 = apellidocliente1;
    }

    public String getApellidocliente2() {
        return apellidocliente2;
    }

    public void setApellidocliente2(String apellidocliente2) {
        this.apellidocliente2 = apellidocliente2;
    }

    public String getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(String fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public int getNumerotelefono() {
        return numerotelefono;
    }

    public void setNumerotelefono(int numerotelefono) {
        this.numerotelefono = numerotelefono;
    }


}
