package com.example.cinetec.services;

import com.example.cinetec.entidades.peliculas;
import com.example.cinetec.entidades.sucursales;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PeliculaService {
    String API_ROUTE = "pelicula";

    @GET(API_ROUTE)
    public Call<List<peliculas>> getpeliculas();
}
