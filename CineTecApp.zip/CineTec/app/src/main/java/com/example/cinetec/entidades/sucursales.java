package com.example.cinetec.entidades;

public class sucursales {

    private String codigosucursal;
    private String nombre;
    private String ubicacion;
    private int cantidadsalas;

    public String getCodigosucursal() {
        return codigosucursal;
    }

    public void setCodigosucursal(String codigosucursal) {
        this.codigosucursal = codigosucursal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String direccion) {
        this.ubicacion = direccion;
    }

    public int getCantidad_salas() {
        return cantidadsalas;
    }

    public void setCantidad_salas(int cantidad_salas) {
        this.cantidadsalas = cantidad_salas;
    }


}
