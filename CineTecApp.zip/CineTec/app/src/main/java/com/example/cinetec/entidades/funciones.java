package com.example.cinetec.entidades;

public class funciones {
    private String funcionid;
    private String salaid;
    private String hora;
    private String peliid;

    public String getFuncionid() {
        return funcionid;
    }

    public void setFuncionid(String funcionid) {
        this.funcionid = funcionid;
    }

    public String getSalaid() {
        return salaid;
    }

    public void setSalaid(String salaid) {
        this.salaid = salaid;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getPeliid() {
        return peliid;
    }

    public void setPeliid(String peliid) {
        this.peliid = peliid;
    }






}
