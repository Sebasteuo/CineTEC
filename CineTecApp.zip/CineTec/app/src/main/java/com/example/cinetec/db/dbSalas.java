package com.example.cinetec.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.cinetec.entidades.salas;

import java.util.ArrayList;

public class dbSalas extends DbHelper {
    Context context;

    public dbSalas(@Nullable Context context) {
        super(context);
        this.context = context;
    }


    public long insertarSala(String SalaID, int Columna, int Fila, int Capacidad) {

        long id = 0;

        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("SalaID", SalaID);
            values.put("Columna", Columna);
            values.put("Fila", Fila);
            values.put("Capacidad", Capacidad);

            id = db.insert(TABLE_SALA, null, values);
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }

    public ArrayList<salas> mostrarSucursales() {

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<salas> listasalas = new ArrayList<>();
        salas sala;
        Cursor cursorSala;

        cursorSala = db.rawQuery("SELECT * FROM " + TABLE_SALA, null);

        if (cursorSala.moveToFirst()) {
            do {
                sala = new salas();
                sala.setSalaID(cursorSala.getString(0));
                sala.setColumna(cursorSala.getInt(1));
                sala.setFila(cursorSala.getInt(2));
                sala.setCapacidad(cursorSala.getInt(3));
                listasalas.add(sala);
            } while (cursorSala.moveToNext());
        }

        cursorSala.close();

        return listasalas;
    }
}
