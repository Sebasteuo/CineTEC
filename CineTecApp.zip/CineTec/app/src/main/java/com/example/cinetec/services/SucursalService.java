package com.example.cinetec.services;

import com.example.cinetec.entidades.sucursales;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface SucursalService {
    String API_ROUTE = "sucursal";

    @GET(API_ROUTE)
    public Call<List<sucursales>> getsucursales();
}
