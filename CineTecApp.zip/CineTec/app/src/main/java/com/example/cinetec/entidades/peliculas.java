package com.example.cinetec.entidades;

public class peliculas {
    private String peliid ;
    private String nombreogpelicula;
    private String nombre;
    private int duracion ;
    private String  imagen;
    private int preciocidoro ;
    private int precioninos ;
    private int precioadulto ;
    private int cedulaempleado ;

    public String getPeliid() {
        return peliid;
    }

    public void setPeliid(String peliid) {
        this.peliid = peliid;
    }

    public String getNombreogpelicula() {
        return nombreogpelicula;
    }

    public void setNombreogpelicula(String nombreogpelicula) {
        this.nombreogpelicula = nombreogpelicula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getPreciocidoro() {
        return preciocidoro;
    }

    public void setPreciocidoro(int preciocidoro) {
        this.preciocidoro = preciocidoro;
    }

    public int getPrecioninos() {
        return precioninos;
    }

    public void setPrecioninos(int precioninos) {
        this.precioninos = precioninos;
    }

    public int getPrecioadulto() {
        return precioadulto;
    }

    public void setPrecioadulto(int precioadulto) {
        this.precioadulto = precioadulto;
    }

    public int getCedulaempleado() {
        return cedulaempleado;
    }

    public void setCedulaempleado(int cedulaempleado) {
        this.cedulaempleado = cedulaempleado;
    }
}
