package com.example.cinetec;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.cinetec.db.DbHelper;
import com.example.cinetec.db.dbSucursales;
import com.example.cinetec.entidades.sucursales;
import com.example.cinetec.services.SucursalService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class principal extends AppCompatActivity {

    private ListView lvSucur;
    private ArrayList<String> nombresucursales = new ArrayList<String>();
    private ArrayList<sucursales> objsucur = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        nombresucursales.clear();
        lvSucur = (ListView) findViewById(R.id.lv_sucursales);


        objsucur=getlist();
        nombresucursales=getlistnombre(objsucur);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, R.layout.list_item, nombresucursales);
        lvSucur.setAdapter(adapter1);

        lvSucur.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent peli_acti = new Intent(getApplicationContext(), peli_acti.class);
                peli_acti.putExtra("info", nombresucursales.get(position));
                peli_acti.putExtra("idsucur", objsucur.get(position).getCodigosucursal());
                startActivity(peli_acti);
            }
        });
        actualizaBDSQlite();
    }

    private boolean verificaConexionInternet() {

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }

    private void actualizaBDSQlite(){
        if (verificaConexionInternet()){
            resetearTablasucursales();
            getSucur();
        }else{
            Toast.makeText(this,"Sin acceso a internet. Uso de datos locales",Toast.LENGTH_LONG).show();
        }
    }

    public void resetearTablasucursales(){
        DbHelper dbHelper= new DbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DROP TABLE t_Sucursales");

        db.execSQL("CREATE TABLE t_Sucursales (CodigoSucursal TEXT PRIMARY KEY,Nombre TEXT NOT NULL,Ubicacion TEXT NOT NULL,CantidadSalas INTEGER NOT NULL)");
    }


    public void insertandosucursal(List<sucursales> lista){
        dbSucursales dbcl= new dbSucursales(this);

        for(int i=0; i<lista.size();i++) {

            sucursales Sc = lista.get(i);
            String codigo = Sc.getCodigosucursal();
            String Nombre = Sc.getNombre();
            String ubicacion = Sc.getUbicacion();
            int cantidadSalas = Sc.getCantidad_salas();

            dbcl.insertarSucursal(codigo,Nombre,ubicacion,cantidadSalas);
        }
    }

    private void getSucur() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.118:8081/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        SucursalService sucurService = retrofit.create(SucursalService.class);
        Call<List<sucursales>> call = sucurService.getsucursales();

        List<sucursales> listasur;
        call.enqueue(new Callback<List<sucursales>>() {
            @Override
            public void onResponse(Call<List<sucursales>> call, Response<List<sucursales>> response) {
                try {
                    if (response.isSuccessful()) {
                        List<sucursales> ScList = response.body();
                        insertandosucursal(ScList);
                        //Toast.makeText(inicial.this, "Exitoso", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(principal.this, "Unsuccessful Clients GET", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Toast.makeText(principal.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<sucursales>> call, Throwable t) {
                Toast.makeText(principal.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    public ArrayList<String> getlistnombre(ArrayList<sucursales> lista){

        ArrayList<String> listaNombressucursales = new ArrayList<>();

        int i=0;
        while (i < lista.size()){
            listaNombressucursales.add(lista.get(i).getNombre());
            i++;
        }
        return listaNombressucursales;
    }

    public ArrayList<sucursales> getlist(){
        dbSucursales dbsucur= new dbSucursales(this);
        ArrayList<sucursales> listasucursales = new ArrayList<>();
        listasucursales=dbsucur.mostrarSucursales();

        return listasucursales;
    }



}
