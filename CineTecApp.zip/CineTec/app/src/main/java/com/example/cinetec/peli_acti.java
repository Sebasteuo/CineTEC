package com.example.cinetec;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cinetec.db.DbHelper;
import com.example.cinetec.db.dbPeliculas;
import com.example.cinetec.db.dbSucursales;
import com.example.cinetec.entidades.peliculas;
import com.example.cinetec.entidades.sucursales;
import com.example.cinetec.services.PeliculaService;
import com.example.cinetec.services.SucursalService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class peli_acti extends AppCompatActivity {

    private TextView tv1;
    private ListView lvcarte;
    private ArrayList<String> nombrecartelera = new ArrayList<>();
    private ArrayList<peliculas> objpeli = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_peli_acti);

        tv1= (TextView)findViewById(R.id.tx_1);
        String dato= getIntent().getStringExtra("info");
        tv1.setText("Sucursal " + dato);

        lvcarte = (ListView) findViewById(R.id.listVcarte);
        objpeli=getlist();
        nombrecartelera=getlistnombre(objpeli);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, R.layout.list_item, nombrecartelera);
        lvcarte.setAdapter(adapter1);

        lvcarte.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent proyec_pel = new Intent(getApplicationContext(), proyec_peli.class);
                proyec_pel.putExtra("nom", nombrecartelera.get(position));
                proyec_pel.putExtra("PeliID", objpeli.get(position).getPeliid());

                startActivity(proyec_pel);
            }
        });

        actualizaBDSQlite();
    }


    private boolean verificaConexionInternet() {

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }

    private void actualizaBDSQlite(){
        if (verificaConexionInternet()){
            resetearTablapeli();
            getpelis();
        }else{
            Toast.makeText(this,"Sin acceso a internet. Uso de datos locales",Toast.LENGTH_LONG).show();
        }
    }

    public void resetearTablapeli(){
        DbHelper dbHelper= new DbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DROP TABLE t_Peliculas");

        db.execSQL("CREATE TABLE t_Peliculas (PeliID TEXT PRIMARY KEY,NombreOgPelicula TEXT NOT NULL,Nombre TEXT NOT NULL,Duracion INT NOT NULL,Imagen TEXT NOT NULL,PrecioCidOro INT NOT NULL,PrecioNinos INT NOT NULL,PrecioAdulto INT NOT NULL,CedulaEmpleado INT NOT NULL)");
    }


    public void insertandopeli(List<peliculas> lista){
        dbPeliculas dbpeli= new dbPeliculas(this);

        for(int i=0; i<lista.size();i++) {

            peliculas Pl = lista.get(i);
            String peliid = Pl.getPeliid();
            String nombreori = Pl.getNombreogpelicula();
            String nombre = Pl.getNombre();
            int duracion = Pl.getDuracion();
            String imagen = Pl.getImagen();
            int preciocoro = Pl.getPreciocidoro();
            int precionino = Pl.getPrecioninos();
            int precioadul = Pl.getPrecioadulto();
            int cedempl = Pl.getCedulaempleado();

            dbpeli.insertarPelicula(peliid,nombreori,nombre,duracion,imagen,preciocoro, precionino,precioadul,cedempl);
        }
    }

    private void getpelis() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.118:8081/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        PeliculaService peliService = retrofit.create(PeliculaService.class);
        Call<List<peliculas>> call = peliService.getpeliculas();

        List<peliculas> listasur;
        call.enqueue(new Callback<List<peliculas>>() {
            @Override
            public void onResponse(Call<List<peliculas>> call, Response<List<peliculas>> response) {
                try {
                    if (response.isSuccessful()) {
                        List<peliculas> PlList = response.body();
                        insertandopeli(PlList);
                        //Toast.makeText(inicial.this, "Exitoso", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(peli_acti.this, "Unsuccessful Clients GET", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Toast.makeText(peli_acti.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<peliculas>> call, Throwable t) {
                Toast.makeText(peli_acti.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }


    public ArrayList<String> getlistnombre(ArrayList<peliculas> lista){

        ArrayList<String> listaNombresPeliculas = new ArrayList<>();

        int i=0;
        while (i < lista.size()){
            listaNombresPeliculas.add(lista.get(i).getNombreogpelicula());
            i++;
        }
        return listaNombresPeliculas;
    }

    public ArrayList<peliculas> getlist(){
        dbPeliculas dbsucur= new dbPeliculas(this);
        ArrayList<peliculas> listapeliculas = new ArrayList<>();
        listapeliculas=dbsucur.mostrarPeliculas();

        return listapeliculas;
    }
}
