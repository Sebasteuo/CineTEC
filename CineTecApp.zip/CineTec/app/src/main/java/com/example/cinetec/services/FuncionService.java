package com.example.cinetec.services;

import com.example.cinetec.entidades.funciones;
import com.example.cinetec.entidades.peliculas;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface FuncionService {
    String API_ROUTE = "funcion";

    @GET(API_ROUTE)
    public Call<List<funciones>> getfuncion();
}
