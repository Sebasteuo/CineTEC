package com.example.cinetec;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cinetec.db.DbHelper;
import com.example.cinetec.db.dbClientes;
import com.example.cinetec.entidades.Cliente;
import com.example.cinetec.services.ClienteService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class inicial extends AppCompatActivity {


    private EditText txt_user, text_pass;
    private List<Cliente> ClienteListafinal;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicial);

        txt_user=(EditText)findViewById(R.id.editText_user);
        text_pass=(EditText)findViewById(R.id.editText_pass);

        actualizaBDSQlite();


    }

    public void Ingresar(View view){
        String cedula= text_pass.getText().toString();
        String nombre = txt_user.getText().toString();

        if (verificar(cedula,nombre)){
            Intent ingresar = new Intent(this, principal.class);
            //ingresar.putExtra("size",size);
            startActivity(ingresar);
        }
        else{
            Toast.makeText(this,"Ingreso algun valor incorrecto o el cliente no esta registrado",Toast.LENGTH_LONG).show();
        }
    }

    private boolean verificaConexionInternet() {

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }


    public void registrarse(View view){
        Intent regis = new Intent(this, registrar.class);
        startActivity(regis);
    }

    private void actualizaBDSQlite(){
        if (verificaConexionInternet()){
            //verficar si hay elementos no sincronizados
            resetearTablaCliente();
            getclientes();
        }else{
            Toast.makeText(this,"Sin acceso a internet. Uso de datos locales",Toast.LENGTH_LONG).show();
        }
    }

    public void resetearTablaCliente(){
        DbHelper dbHelper= new DbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DROP TABLE t_Clientes");

        db.execSQL("CREATE TABLE t_Clientes (cedulacliente INT PRIMARY KEY,nombrecliente1 TEXT NOT NULL,nombrecliente2 TEXT NOT NULL,apellidocliente1 TEXT NOT NULL,apellidocliente2 TEXT NOT NULL,fechanacimiento TEXT NOT NULL,numerotelefono INT NOT NULL,estado_sincro INT NOT NULL)");
    }


    public void insertandocliente(List<Cliente> lista){
            dbClientes dbcl= new dbClientes(this);

            for(int i=0; i<lista.size();i++) {

                Cliente cl = lista.get(i);
                int CedulaCliente = cl.getCedulacliente();
                String NombreCliente1 = cl.getNombrecliente1();
                String NombreCliente2 = cl.getNombrecliente2();
                String ApellidoCliente1 = cl.getApellidocliente1();
                String pellidoCliente2 = cl.getApellidocliente2();
                String FechaNacimiento = cl.getFechanacimiento();
                int NumeroTelefono = cl.getNumerotelefono();
                int estado_sincro = 1;
                dbcl.insertarCliente(CedulaCliente, NombreCliente1, NombreCliente2, ApellidoCliente1, pellidoCliente2, FechaNacimiento, NumeroTelefono, estado_sincro);
            }
    }

   public boolean verificar(String cedula, String nombre){
        dbClientes dbclien= new dbClientes(this);
        ArrayList<Cliente> listaclientes = new ArrayList<>();
        listaclientes=dbclien.mostrarClientes();

        int i=0;
        while (i< listaclientes.size()){
            String auxcedula= String.valueOf(listaclientes.get(i).getCedulacliente());
            String auxnom= listaclientes.get(i).getNombrecliente1();
            if (auxcedula.equalsIgnoreCase(cedula) && auxnom.equalsIgnoreCase(nombre)) {
                return true;
            }
            i++;
        }
        return false;
    }



    private void getclientes() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.119:8081/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ClienteService clenteService = retrofit.create(ClienteService.class);
        Call<List<Cliente>> call = clenteService.getclientes();

        List<Cliente> listaclientes;
        call.enqueue(new Callback<List<Cliente>>() {
            @Override
            public void onResponse(Call<List<Cliente>> call, Response<List<Cliente>> response) {
                try {
                    if (response.isSuccessful()) {
                        List<Cliente> ClList = response.body();
                        insertandocliente(ClList);
                        //Toast.makeText(inicial.this, "Exitoso", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(inicial.this, "Unsuccessful Clients GET", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Toast.makeText(inicial.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Cliente>> call, Throwable t) {
                Toast.makeText(inicial.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}
