package com.example.cinetec;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cinetec.db.dbClientes;
import com.example.cinetec.entidades.Cliente;
import com.example.cinetec.services.ClienteService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class registrar extends AppCompatActivity {

    private EditText etced,etnom1,etnom2,etape1,etape2,etfech,ettel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        etced= (EditText)findViewById(R.id.editText_ced);
        etnom1= (EditText)findViewById(R.id.editText_nom1);
        etnom2= (EditText)findViewById(R.id.editText_nom2);
        etape1= (EditText)findViewById(R.id.editText_ape1);
        etape2= (EditText)findViewById(R.id.editText_ape2);
        etfech= (EditText)findViewById(R.id.editText_fechana);
        ettel= (EditText)findViewById(R.id.editText_telef);

        //actualizaBDPosgresql();
    }

    private void postCliente(Cliente cl){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.1.119:8081/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ClienteService clenteService = retrofit.create(ClienteService.class);
        Call<Cliente> call = clenteService.PostCliente(cl);


        call.enqueue(new Callback<Cliente>() {
            @Override
            public void onResponse(Call<Cliente> call, retrofit2.Response<Cliente> response) {
                try {
                    if (!response.isSuccessful()) {
                        Toast.makeText(registrar.this, "No sepudo", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(registrar.this, "si se pudo", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception exception) {
                    Toast.makeText(registrar.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Cliente> call, Throwable t) {
                Toast.makeText(registrar.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void registrando(View view){
        int cedula= Integer.parseInt(etced.getText().toString());
        String nom1= etnom1.getText().toString();
        String nom2= etnom2.getText().toString();
        String ape1= etape1.getText().toString();
        String ape2= etape2.getText().toString();
        String fechana= etfech.getText().toString();
        int telef= Integer.parseInt(ettel.getText().toString());


        if(verificaConexionInternet()){
            dbClientes dbclien = new dbClientes(this);
            dbclien.insertarCliente(cedula, nom1, nom2, ape1, ape2, fechana, telef, 1);


            Cliente Ncliente=new Cliente();
            Ncliente.setCedulacliente(cedula);
            Ncliente.setNombrecliente1(nom1);
            Ncliente.setNombrecliente2(nom2);
            Ncliente.setApellidocliente1(ape1);
            Ncliente.setApellidocliente2(ape2);
            Ncliente.setFechanacimiento(fechana);
            Ncliente.setNumerotelefono(telef);
            Ncliente.setUsuario("perico");
            Ncliente.setContrasenna("111");

            //hacer post a la api
            postCliente(Ncliente);

        }else {
            dbClientes dbclien = new dbClientes(this);
            dbclien.insertarCliente(cedula, nom1, nom2, ape1, ape2, fechana, telef, 0);
        }

        Intent regresar = new Intent(this, inicial.class);
        startActivity(regresar);
    }

    private boolean verificaConexionInternet() {

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        return (networkInfo != null && networkInfo.isConnected());
    }


}
