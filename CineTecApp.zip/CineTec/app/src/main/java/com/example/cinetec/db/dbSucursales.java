package com.example.cinetec.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.cinetec.entidades.sucursales;

import java.util.ArrayList;

public class dbSucursales extends DbHelper {
    Context context;

    public dbSucursales(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public void insertarSucursal(String codigosucursal,String nombre, String ubicacion, int cantidad_salas) {



        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("CodigoSucursal",codigosucursal);
            values.put("Nombre", nombre);
            values.put("Ubicacion", ubicacion);
            values.put("CantidadSalas", cantidad_salas);

            db.insert(TABLE_SUCURSALES, null, values);
        } catch (Exception ex) {
            ex.toString();
        }


    }

    public ArrayList<sucursales> mostrarSucursales() {

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<sucursales> listasucursales = new ArrayList<>();
        sucursales sucursal;
        Cursor cursorSucursales;

        cursorSucursales = db.rawQuery("SELECT * FROM " + TABLE_SUCURSALES, null);

        if (cursorSucursales.moveToFirst()) {
            do {
                sucursal = new sucursales();
                sucursal.setCodigosucursal(cursorSucursales.getString(0));
                sucursal.setNombre(cursorSucursales.getString(1));
                sucursal.setUbicacion(cursorSucursales.getString(2));
                sucursal.setCantidad_salas(cursorSucursales.getInt(3));
                listasucursales.add(sucursal);
            } while (cursorSucursales.moveToNext());
        }

        cursorSucursales.close();

        return listasucursales;
    }
}
