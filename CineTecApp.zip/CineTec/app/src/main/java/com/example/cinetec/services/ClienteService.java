package com.example.cinetec.services;

import com.example.cinetec.entidades.Cliente;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ClienteService {
    String API_ROUTE = "cliente";

    @POST(API_ROUTE)
    public Call<Cliente> PostCliente(@Body Cliente Cliente );

    @GET(API_ROUTE)
    public Call<List<Cliente>> getclientes();

}
