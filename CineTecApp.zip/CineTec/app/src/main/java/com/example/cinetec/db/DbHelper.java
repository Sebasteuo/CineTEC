package com.example.cinetec.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NOMBRE= "Cines.db";
    public static final String TABLE_SUCURSALES= "t_Sucursales";
    public static final String TABLE_CLIENTES= "t_Clientes";
    public static final String TABLE_PELICULAS= "t_Peliculas";
    public static final String TABLE_SALA= "t_Sala";
    public static final String TABLE_FUNCION= "t_Funcion";


    public DbHelper(@Nullable Context context) {
        super(context,DATABASE_NOMBRE, null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
         db.execSQL("CREATE TABLE " + TABLE_SUCURSALES + "(" +
                 "CodigoSucursal TEXT PRIMARY KEY," +
                 "Nombre TEXT NOT NULL," +
                 "Ubicacion TEXT NOT NULL," +
                 "CantidadSalas INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_CLIENTES + "(" +
                "cedulacliente INT PRIMARY KEY,"+
                "nombrecliente1 TEXT NOT NULL," +
                "nombrecliente2 TEXT NOT NULL," +
                "apellidocliente1 TEXT NOT NULL," +
                "apellidocliente2 TEXT NOT NULL," +
                "fechanacimiento TEXT NOT NULL," +
                "numerotelefono INT NOT NULL,"+
                //"usuario TEXT NOT NULL," +
                //"contrasenna TEXT NOT NULL," +
                "estado_sincro INT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_PELICULAS + "(" +

                "PeliID TEXT PRIMARY KEY," +
                "NombreOgPelicula TEXT NOT NULL," +
                "Nombre TEXT NOT NULL," +
                "Duracion INT NOT NULL,"+
                "Imagen TEXT NOT NULL," +
                "PrecioCidOro INT NOT NULL,"+
                "PrecioNinos INT NOT NULL,"+
                "PrecioAdulto INT NOT NULL,"+
                "CedulaEmpleado INT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_SALA + "(" +

                "SalaID TEXT PRIMARY KEY," +
                "Columna INT NOT NULL,"+
                "Fila INT NOT NULL,"+
                "Capacidad INT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_FUNCION + "(" +

                "SalaID TEXT NOT NULL," +
                "Hora TEXT NOT NULL," +
                "PeliID TEXT NOT NULL,"+
                "FuncionID TEXT PRIMARY KEY)");
    }


        @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE " + TABLE_SUCURSALES);
        db.execSQL("DROP TABLE " + TABLE_CLIENTES);
        db.execSQL("DROP TABLE " + TABLE_PELICULAS);
        db.execSQL("DROP TABLE " + TABLE_SALA);
        db.execSQL("DROP TABLE " + TABLE_FUNCION);
        onCreate(db);
    }
}
