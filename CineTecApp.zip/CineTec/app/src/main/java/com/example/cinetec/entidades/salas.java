package com.example.cinetec.entidades;

public class salas {
    private String SalaID ;
    private int Columna ;
    private int Fila  ;
    private int Capacidad  ;

    public String getSalaID() {
        return SalaID;
    }

    public void setSalaID(String salaID) {
        SalaID = salaID;
    }

    public int getColumna() {
        return Columna;
    }

    public void setColumna(int columna) {
        Columna = columna;
    }

    public int getFila() {
        return Fila;
    }

    public void setFila(int fila) {
        Fila = fila;
    }

    public int getCapacidad() {
        return Capacidad;
    }

    public void setCapacidad(int capacidad) {
        Capacidad = capacidad;
    }


}
