package com.example.cinetec.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.cinetec.entidades.peliculas;

import java.util.ArrayList;

public class dbPeliculas extends DbHelper {
    Context context;

    public dbPeliculas(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public void insertarPelicula(String PeliID, String NombreOgPelicula, String Nombre, int Duracion, String  Imagen, int PrecioCidOro, int PrecioNinos, int PrecioAdulto,int CedulaEmpleado){

        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("PeliID", PeliID);
            values.put("NombreOgPelicula", NombreOgPelicula);
            values.put("Nombre", Nombre);
            values.put("Duracion", Duracion);
            values.put("Imagen", Imagen);
            values.put("PrecioCidOro", PrecioCidOro);
            values.put("PrecioNinos", PrecioNinos);
            values.put("PrecioAdulto", PrecioAdulto);
            values.put("CedulaEmpleado", CedulaEmpleado);

            db.insert(TABLE_PELICULAS, null, values);
        } catch (Exception ex) {
            ex.toString();
        }


    }

    public ArrayList<peliculas> mostrarPeliculas() {

        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<peliculas> listapeliculas = new ArrayList<>();
        peliculas pelicula;
        Cursor cursorPeliculas;

        cursorPeliculas = db.rawQuery("SELECT * FROM " + TABLE_PELICULAS, null);

        if (cursorPeliculas.moveToFirst()) {
            do {
                pelicula = new peliculas();
                pelicula.setPeliid(cursorPeliculas.getString(0));
                pelicula.setNombreogpelicula(cursorPeliculas.getString(1));
                pelicula.setNombre(cursorPeliculas.getString(2));
                pelicula.setDuracion(cursorPeliculas.getInt(3));
                pelicula.setImagen(cursorPeliculas.getString(4));
                pelicula.setPreciocidoro(cursorPeliculas.getInt(5));
                pelicula.setPrecioninos(cursorPeliculas.getInt(6));
                pelicula.setPrecioadulto(cursorPeliculas.getInt(7));
                pelicula.setCedulaempleado(cursorPeliculas.getInt(8));
                listapeliculas.add(pelicula);
            } while (cursorPeliculas.moveToNext());
        }

        cursorPeliculas.close();

        return listapeliculas;
    }
}
